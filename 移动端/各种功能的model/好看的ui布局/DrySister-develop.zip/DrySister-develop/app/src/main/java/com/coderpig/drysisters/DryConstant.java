package com.coderpig.drysisters;

/**
 * 描述：相关常量
 *
 * @author CoderPig on 2018/02/13 16:22.
 */

public class DryConstant {
    public final static String FG_LITTLE_SISTER = "FG_LITTLE_SISTER";
    public final static String FG_NEWS = "FG_NEWS";
    public final static String FG_WEATHER = "FG_WEATHER";
    public final static String FG_SUBWAY = "FG_SUBWAY";
    public final static String FG_TOOLS = "FG_TOOLS";
}
