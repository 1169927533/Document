package com.example.apple.huanxin.presenter;

/**
 * Created by apple on 16/12/23.
 */

public interface IChatPresenter {

    void setMessage(String msg);
}
