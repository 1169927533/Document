var searchData=
[
  ['server_5fbusy',['SERVER_BUSY',['../classcom_1_1hyphenate_1_1EMError.html#acb17152172d3af150b3906f06ae26ea2',1,'com::hyphenate::EMError']]],
  ['server_5fget_5fdnslist_5ffailed',['SERVER_GET_DNSLIST_FAILED',['../classcom_1_1hyphenate_1_1EMError.html#a47bf219f00f9413678eef16120841186',1,'com::hyphenate::EMError']]],
  ['server_5fnot_5freachable',['SERVER_NOT_REACHABLE',['../classcom_1_1hyphenate_1_1EMError.html#aa3d81fcde062618d9f81c1cb3e00ad11',1,'com::hyphenate::EMError']]],
  ['server_5fservice_5frestricted',['SERVER_SERVICE_RESTRICTED',['../classcom_1_1hyphenate_1_1EMError.html#a8b258f5de26370c55891d52e72101411',1,'com::hyphenate::EMError']]],
  ['server_5ftimeout',['SERVER_TIMEOUT',['../classcom_1_1hyphenate_1_1EMError.html#a0c2644b11ada9016f40e9be20d1116ad',1,'com::hyphenate::EMError']]],
  ['server_5funknown_5ferror',['SERVER_UNKNOWN_ERROR',['../classcom_1_1hyphenate_1_1EMError.html#ae913315d6d8b7cf71c061e5440b87cb6',1,'com::hyphenate::EMError']]],
  ['shareview',['shareView',['../classcom_1_1hyphenate_1_1chat_1_1EMStreamParam.html#af6c63073334df4b09fc81a4f5a3b2c8e',1,'com::hyphenate::chat::EMStreamParam']]],
  ['streamtype',['streamType',['../classcom_1_1hyphenate_1_1chat_1_1EMStreamParam.html#a1a196f933b8504073732bcb19900699a',1,'com::hyphenate::chat::EMStreamParam']]],
  ['style',['style',['../classcom_1_1hyphenate_1_1chat_1_1EMGroupOptions.html#afb7c3b6e0bdea5d0784971a6a0b9026c',1,'com::hyphenate::chat::EMGroupOptions']]]
];
