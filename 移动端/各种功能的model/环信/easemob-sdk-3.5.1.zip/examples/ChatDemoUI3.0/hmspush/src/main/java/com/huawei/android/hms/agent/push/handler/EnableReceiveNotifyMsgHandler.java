package com.huawei.android.hms.agent.push.handler;

import com.huawei.android.hms.agent.common.ICallbackCode;

/**
 * enableReceiveNotifyMsg 回调
 */
public interface EnableReceiveNotifyMsgHandler extends ICallbackCode {
}
