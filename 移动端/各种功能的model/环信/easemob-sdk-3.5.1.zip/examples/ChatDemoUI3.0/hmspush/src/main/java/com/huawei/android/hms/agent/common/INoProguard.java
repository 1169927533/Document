package com.huawei.android.hms.agent.common;

/**
 * 不混淆类
 */
public interface INoProguard {
}
